# all data: 323480
# train data: 226436
#validation data: 64696
# test data: 32348

import random
import shutil

def choose_indices(num_samples):
    train_num = int(num_samples*0.7)
    val_num = int(num_samples * 0.2)
    test_num = int(num_samples - val_num - train_num)

    train = []
    val = []
    test = []

    random.seed(100)
    temp = random.sample(range(num_samples), num_samples)
    train = temp[0:train_num]
    val = temp[train_num:train_num+val_num]
    test = temp[(train_num+val_num):(train_num+val_num+test_num)]

    #removing repeated index
    set_train = set(train)
    set_test = set(test)
    set_val = set(val)

    print(len(test))
    print(len(val))
    print(len(train))
    print("----------------------------")
    print(len(set_train))
    print(len(set_val))
    print(len(set_test))

    return train,val,test

def copy_train(train_indices):
    len_data = len(train_indices)
    for i in range(len_data):
        if i%1000 == 0:
            print(i)
        original = 'F:/ehsan/normal2/img'+str(train_indices[i])+'.jpg'
        target = 'F:/ehsan/dataset/train/pristine/'+ str(i) +'.jpg'
        shutil.copyfile(original, target)

    print("train finished")


def copy_val(val_indices):
    len_data = len(val_indices)
    for i in range(len_data):
        if i%1000 == 0:
            print(i)
        original = 'F:/ehsan/normal2/img' + str(val_indices[i]) + '.jpg'
        target = 'F:/ehsan/dataset/validation/pristine/' + str(i) + '.jpg'
        shutil.copyfile(original, target)

    print("validation finished")


def copy_test(test_indices):
    len_data = len(test_indices)
    for i in range(len_data):
        if i%1000 == 0:
            print(i)
        original = 'F:/ehsan/normal2/img' + str(test_indices[i]) + '.jpg'
        target = 'F:/ehsan/dataset/test/pristine/' + str(i) + '.jpg'
        shutil.copyfile(original, target)

    print("test finished")

train, test, val = choose_indices(323480)
copy_train(train)
copy_val(val)
copy_test(test)

