import foolbox
from foolbox.models import KerasModel
import numpy as np
import matplotlib.pyplot as plt
from tensorflow import keras
from keras.models import load_model
from keras.datasets import mnist
from imageio import imread
from glob import glob
#from utils import force_linear_activation
import cv2
from PIL import Image
import math
import tensorflow as tf
import statistics
import datetime
import os

# GPU management
config2 = tf.compat.v1.ConfigProto()
config2.gpu_options.allow_growth = True
session = tf.compat.v1.InteractiveSession(config=config2)

gpus = tf.config.experimental.list_physical_devices('GPU')
print(tf.config.experimental.set_memory_growth(gpus[0], True))
tf.compat.v1.disable_eager_execution()
print(tf.config.list_physical_devices("GPU"))

def show_figures(I, Z, true_score,adv_score):
    plt.figure()

    true_class = np.argmax(true_score)
    adv_class = np.argmax(adv_score)

    plt.subplot(1, 3, 1)
    plt.title('Original (class {}, score {:2.2f})'.format(true_class, true_score[true_class]))
    plt.imshow(I, cmap=plt.get_cmap('gray'))  # division by 255 to convert [0, 255] to [0, 1]
    plt.axis('off')

    plt.subplot(1, 3, 2)
    plt.title('Adversarial (class {}, score {:2.2f})'.format(adv_class, adv_score[adv_class]))
    plt.imshow(Z, cmap=plt.get_cmap('gray'))  # ::-1 to convert BGR to RGB
    plt.axis('off')

    plt.subplot(1, 3, 3)
    plt.title('Difference')
    difference = np.double(Z) - np.double(I)  # Z - I
    plt.imshow(difference,cmap=plt.get_cmap('Blues'))# / abs(difference).max() * 0.2 + 0.5)
    plt.axis('off')

    plt.show()
    return


def psnr(img1, img2):
    mse = np.mean((img1 - img2) ** 2)
    if mse == 0:
        return 100
    PIXEL_MAX = 255.0
    return 20 * math.log10(PIXEL_MAX / math.sqrt(mse))

def column(matrix, i):
    return [row[i] for row in matrix]


if __name__ == '__main__':

    def main():

        # Load Keras model
        model = load_model('/home/mhm/ehsan/Networks/Networks/Codes/Aware_Models/BayerNet/BayerNet_BIM_ep_10.h5')  #First model
        print(model)

        # Switch softmax with linear activations -- per evitare il softmax
        Ptype =  'probabilities' #'logits' # 'probabilities'


        # 64x64, 2 digits
        img_rows, img_cols, img_chans = 64,64, 1
        input_shape = (img_rows, img_cols, img_chans)
        num_classes = 2

        jpeg_quality = 85
        jpeg = 0 # 'true'
        compressJPEG =  0 #'true'

        #---------------------------------------------------------
        #  Load test data and define labels (numImg, 64,64)
        #-----------------------------------------------------------

        images = glob('/home/mhm/ehsan/Network_Model/images/*.jpg')
        #images = glob(r'E:\Benedetta_for_ICASSP\Datasets\StammNetMedian5\vision\128\test\median05\*.png')
        label = 1 # label = 1 for Manipulated, 0 for Pristine  ---  # label = 1 for Original

        # mismatch model: Load Keras model
        #model2 = load_model(r'E:\Benedetta_for_ICASSP\EhsanBowen\StammModels_vision&RAISE\bayar_model_original_vs_resize_128x128_Vision.h5')
        #model2 = load_model(r'/home/m_mhm/ehsan/Network_Model/Model_BayerNet_ImproveSec.h5')
        #label2 = 1

        #numImg = 200 #len(images)  # <= len(images)    #Benedetta

        numImg = len(images)   # Ehsan
        print("Num Imgs:", numImg)
        # We compute accuracy based on numebr of images ( 5 ) #Ehsan
        #numImg = 1

        np.random.seed(1234)
        index = np.random.randint(len(images), size=numImg)

        x_test = np.zeros((numImg, img_rows, img_cols))
        for i in np.arange(numImg):
            img = imread(images[index[i]])  # Flatten=True means convert to gray on the fly
            if compressJPEG:
                img1 = Image.fromarray(img)
                img1.save('temp.jpeg', "JPEG", quality=jpeg_quality)
                img = Image.open('temp.jpeg')
            x_test[i] = img

        # Labels of authentic images = 1 (non-authentic = 0).
        y_test_c = np.tile(label, numImg)


        # Convert labels to one-hot with Keras
        y_test = tf.keras.utils.to_categorical(y_test_c, num_classes)
        #with stamm the first is pristine, the second is manipulated
        #for ICIP the first is manipulated, the second is original

        # Reshape test data, divide by 255 because net was trained this way
        x_test = x_test.reshape(x_test.shape[0], img_rows, img_cols, img_chans)

        x_test = x_test.astype('float32')
        x_test /= 255

        # Test legitimate examples
        score = model.evaluate(x_test, y_test, verbose=0)
        #Returns the loss value (of the loss function) & metrics (accuracy ...) values for the model in test mode
        predicted_legitimate_labels = np.argmax(model.predict(x_test), axis=1)

        print('Accuracy on legitimate images (all): {:3.4f}'.format(score[1]))

        #y_test_c2 = np.tile(label2, numImg)
        #y_test2 = keras.utils.to_categorical(y_test_c2, num_classes)
        #one-hot representation
        #score2 = model2.evaluate(x_test, y_test2, verbose=0)
        # Returns the loss value (of the loss function) & metrics (accuracy ...) values for the model in test mode
        #predicted_legitimate_labels2 = np.argmax(model2.predict(x_test), axis=1)
        #print('Accuracy on legitimate images (all) by mismatched model: {:3.4f}'.format(score2[1]))



        # ----------------------------------------------------------------------------------------------------------------------
        # Attack the first image of the test set
        # ----------------------------------------------------------------------------------------------------------------------

        # Wrap model
        fmodel = KerasModel(model, bounds=(0, 1), predicts=Ptype)

        # Prepare attack
        attack = foolbox.attacks.IterativeGradientSignAttack(fmodel)
        #attack = foolbox.attacks.GradientSignAttack(fmodel)            #Gradient.py
        # attack = foolbox.attacks.DeepFoolAttack(fmodel)                 #Deepfool.py
        # attack = foolbox.attacks.SaliencyMapAttack(fmodel)             #Saleincy.py
        # attack = foolbox.attacks.LBFGSAttack(fmodel)
        #attack = foolbox.attacks.iterative_projected_gradient.LinfinityBasicIterativeAttack(fmodel)   #BIM #iterative_projected_gradient.py--->LinfinityBasicIterativeAttack
        #attack = foolbox.attacks.iterative_projected_gradient.ProjectedGradientDescentAttack(fmodel)   #PGS #iterative_projected_gradient.py-->ProjectedGradientDescentAttack
        #attack = foolbox.attacks.carlini_wagner.CarliniWagnerL2Attack(fmodel)  # Carnili and Wagner Attack #carlini_wagner.py


        # ------Get data, labels and categorical labels ***only for correctly classified examples***
        l = np.argwhere(predicted_legitimate_labels == y_test_c).shape[0]

        x_test_ok = np.reshape(x_test[np.array(np.argwhere(predicted_legitimate_labels == y_test_c)), :, :, :], (l, img_rows,
                                                                                                                 img_cols,
                                                                                                                img_chans))
        test_ok_index = index[np.array(np.argwhere(predicted_legitimate_labels == y_test_c))]

        # x_test_ok are the images that are correctly classified by the first model since we do not want to attack misclassified images

        y_test_ok = np.reshape(y_test[np.argwhere(predicted_legitimate_labels == y_test_c), :], (l, num_classes))
        y_test_c_ok = np.argmax(y_test_ok, axis=1)


        #y_test_c_ok_2 = np.tile(label2, l)
        #y_test_ok_2 = keras.utils.to_categorical(y_test_c_ok_2, num_classes)
        #score3 = model2.evaluate(x_test_ok, y_test_ok_2, verbose=0)
        #predicted_legitimate_labels2 = np.argmax(model2.predict(x_test_ok), axis=1)

        #l = np.argwhere(predicted_legitimate_labels2 == y_test_c_ok_2).shape[0]
        #x_test_ok = np.reshape(x_test_ok[np.array(np.argwhere(predicted_legitimate_labels2 == y_test_c_ok_2)), :, :, :],
         #                      (l, img_rows,
          #                      img_cols,
           #                     img_chans))
        #y_test_ok = np.reshape(y_test_ok[np.argwhere(predicted_legitimate_labels2 == y_test_c_ok_2), :],
         #                      (l, num_classes))
        #y_test_c_ok = np.argmax(y_test_ok, axis=1)

        #test_ok_index = np.squeeze(test_ok_index[np.array(np.argwhere(predicted_legitimate_labels2 == y_test_c_ok_2))])

        # ------------------


        # Elaborate n_test adversarial examples ***only for correctly classified examples***
        n_test = l  #Benedetta

        #n_test = l    #Ehsan : You're the man Ehsan

        S = 0
        S_k =0
        S_int = 0
        S_jpg  = 0
        avg_Max_dist = 0
        avg_L1_dist = 0
        avg_Max_dist_made_integer = 0
        avg_L1_dist_made_integer = 0
        avg_No_Mod_Pixels = 0
        avg_No_Mod_Pixels_integer_rounding_adv_img = 0
        avg_No_Mod_Pixels_integer_NO_rounding = 0
        PSNR = 0
        t = 0
        avg_psnr = 0
        avg_psnr_int = 0
        psnr_org=0 #for each image
        psnr_Int=0 #for each image
        max_diff_integer=0
        max_diff=0


        adv_images = np.zeros((n_test, img_rows, img_cols, img_chans))
        adv_images_integer = np.zeros((n_test, img_rows, img_cols, img_chans))
        true_labels_cat = []
        adv_score_p1 = []
        #Ehsan Average Score TN
        Average_TrueScore_TN = []

        for idx in np.arange(n_test):
            #n_test should be less than to the length of x_test_ok
            image = x_test_ok[idx]

            true_labels_cat.append(y_test_ok[idx, :])

            image = image.astype('float32')
            image_original = 255 * image.reshape((img_rows, img_cols))

            if compressJPEG:
                img1 = Image.fromarray(np.uint8(255*image[:,:,0]))
                img1.save('temp.jpeg', "JPEG", quality=jpeg_quality)
                img_reread = Image.open('temp.jpeg')
                image = np.array(img_reread)
                image = np.reshape(image, (img_rows, img_cols, img_chans))

            # Print Best Epsilon
            #adv_image_B = attack(image, y_test_c_ok[idx], unpack=False)
            #print('Image {}. Best epsilon is: {}'.format(idx, adv_image_B.best_epsilon[0]))
            #print('Image {}. Best step is: {}'.format(idx, adv_image_B.best_epsilon[1]))

            # Generate adversarial images
            adv_images[idx] = attack(image, y_test_c_ok[idx])
            ## to reload the MORE perturbed attacked image rather than the image returned by the attack
            #adv_images[idx] = np.load(r'E:\tempPerturbed.npy')

            adversarial_image = 255 * adv_images[idx].reshape((img_rows, img_cols))

            path_adv_npy = '/home/mhm/ehsan/Results/C&W_CONF0_TUNNED/npy/'
            with open(path_adv_npy + 'adv_%d.npy' % idx, 'wb') as f:
                np.save(f,adversarial_image)
            path_adv_Image = '/home/mhm/ehsan/Results/C&W_CONF0_TUNNED/Images/'
            adversarial = adversarial_image
            cv2.imwrite(path_adv_Image + 'adv_%d.png' % idx, adversarial)


            #adversarial_image = np.clip(adversarial_image,0,255)
            #Z = np.uint8(adversarial_image)  # ATT! così tronca invece di fare il round !!!!!
            #Z = np.float16(adversarial_image)
            #Z = np.uint8(np.round(adversarial_image))
            # Ehsan, Store adversarial integer images
            ##############################################################################

           # path1='/home/m_mhm/ehsan/Results/IFGSM_epsilon_10/images'
            #path1='E:/Benedetta_for_ICASSP/IMAGE/' #output folder


            #cv2.imwrite(os.path.join(path1, os.path.basename(images[test_ok_index[idx]])), Z)

            ##################################################################################
            #path2 = '''E:\Benedetta_for_ICASSP\IMAGE_Noise\\'''
            #diff_noise=adversarial_image - image_original
            #Noise = np.uint8((diff_noise - np.min(diff_noise)) / (np.max(diff_noise) - np.min(diff_noise)))
            #cv2.imwrite(path2 + 'adv_Nosie_%d.png' % idx, 255*Noise)
            #adv_images_integer[idx] = np.reshape(Z / 255., (img_rows, img_cols, 1))

            #adversarial_image_int = adv_images_integer[idx].reshape((img_rows, img_cols))

            # Scores of legitimate and adversarial images for each idx
            scoreTemp = fmodel.predictions(image)
            true_score = foolbox.utils.softmax(scoreTemp)
            true_class = np.argmax(true_score)
            #it is the ground truth true_class according to network 1
            adv_score = foolbox.utils.softmax(fmodel.predictions(adv_images[idx]))
            adv_score_p1.append(adv_score)
            adv_class = np.argmax(adv_score)
            adv_integer_score = foolbox.utils.softmax(fmodel.predictions(adv_images_integer[idx]))
            adv_integer_class = np.argmax(adv_integer_score)




            print('Image {}. Class changed from {} to {}. The score passes from {} to {}'.format(idx, true_class,
                                                                                                 adv_class, true_score,
                                                                                                 adv_score))
            # the if below is to solve the strange problem with the prediction of a matrix of nan values...
            if np.any(np.isnan(adv_images[idx])):
                adv_class = true_class
                adv_integer_class = true_class
                t = t + 1
                print('An adversarial image cannot be found!!')


            if true_class == adv_class:
                S = S+1
            if true_class == adv_integer_class:
                S_int = S_int + 1

            # plot image, adv_image and difference
            image_before = 255 * image.reshape((img_rows, img_cols))
            X = np.uint8(image_before) # uint8 non ha effetto di troncamento

            psnr_org = psnr(image_before, adversarial_image)
            print('PSNR = {:3.4f}'.format(abs(psnr_org)))

            diff = np.double(image_before) - np.double(adversarial_image)

            print('Max distortion adversarial = {:3.4f}; L1 distortion = {:3.4f}'.format(abs(diff).max(),
                                                                                                 abs(diff).sum() / (
                                                                                                             img_rows * img_cols)))

            # update average distortion
            if true_class != adv_class:
                avg_Max_dist = avg_Max_dist + abs(diff).max()
                avg_L1_dist = avg_L1_dist + abs(diff).sum() / (img_rows * img_cols)
                avg_No_Mod_Pixels = avg_No_Mod_Pixels + np.count_nonzero(diff) / (img_rows * img_cols)
                avg_psnr = avg_psnr + psnr(image_before, adversarial_image)


        n=n_test-S
        n_int=n_test-S_int
        print('Class for the adversarial unchanged: {} over {}'.format(S,n_test))
        print('Average distortion: max dist {}, L1 dist {}'.format(avg_Max_dist/n,avg_L1_dist/n))
        print('Average no of modified pixels: {}'.format(avg_No_Mod_Pixels/n))

        print('The adversarial image cannot be found  {} times over {}'.format(t,n_test))


        print('Average PSNR distortion for JPEG adversarial images : {}'.format(PSNR/n_test))
        print('Average PSNR =: {:3.4f}'.format(avg_psnr / n))

        # Evaluate accuracy
        true_labels_cat = np.array(true_labels_cat)
        adv_score = model.evaluate(adv_images, true_labels_cat, verbose=0)
        #adv_score_p1 = model.predict(adv_images, verbose=0)
        adv_score_integer= model.evaluate(adv_images_integer, true_labels_cat, verbose=0)

        score_perfect = model.evaluate(x_test_ok, y_test_ok, verbose=0)

        print('Accuracy on legitimate images (all) by N1: {:3.4f}'.format(score[1]))
        #print('Accuracy on legitimate images (all) by mismatched model N2: {:3.4f}'.format(score2[1]))  # ????? Score2
        print('Accuracy on legitimate images (only correctly classified, obviously 1) N1: {:3.4f}'.format(score_perfect[1]))
        print('Accuracy on adversarial images N1: {:3.4f}'.format(adv_score[1]))
        print('Attack success rate on adversarial images N1: {:3.4f}'.format(1-adv_score[1]))
        print('Average PSNR =: {:3.4f}'.format(avg_psnr / n))


        # SECOND PART
        # Load the second model and test the adversarial images
        # Label
        #label3 = np.abs(1 - label2)  # it may be different from label because of the differences in the model.

        # Labels
        #y_test_c = np.tile(label2, n_test)

        # Convert labels to one-hot with Keras
        y_test2 = keras.utils.to_categorical(y_test_c, num_classes)

        # Test
        #adv_score_mismatch = model2.evaluate(adv_images, y_test2, verbose=0)
        #adv_score_mismatch_scores = model2.predict(adv_images)


        #print('Accuracy on adversarial images with the mismatched model N2: {:3.4f}'.format(adv_score_mismatch[1]))
        #print('Attack success rate on adversarial images with the mismatched model N2: {:3.4f}'.format(1-adv_score_mismatch[1]))


        col1 = column(adv_score_p1, int(np.abs(1-label)))
        confidence_score_N1 = np.sum(col1) / len(column(adv_score_p1,np.abs(1-label)))
        print("The average score for succesfully attacked images at TN for N1: ", confidence_score_N1)

        #idx2 = int(np.abs(1-label2))
        #col2_tmp = [i[idx2] for i in adv_score_mismatch_scores]
        #col2_tmp_complement = [i[label2] for i in adv_score_mismatch_scores]
        k=0
        confidence_score_N2_tmp=0
        confidence_score_N2_tmp_all_samples=0
        confidence_score_N2=0
        #for ix in range(len(adv_score_mismatch_scores[:,0])):
         #   confidence_score_N2_tmp_all_samples = confidence_score_N2_tmp_all_samples + col2_tmp[ix]
         #   if col2_tmp[ix] > col2_tmp_complement[ix]:
          #      confidence_score_N2_tmp = confidence_score_N2_tmp + col2_tmp[ix]
           #     k+=1

        try:
            confidence_score_N2 = confidence_score_N2_tmp/k
            print("The average score for succesfully attacked images at TN for N2 (transeferable samples): ", confidence_score_N2)
        except:
            print("The average score for succesfully attacked images at TN for N2 (transeferable samples - NO SAMPLES FOUND): ",
                  0)

    #    try:
            #print("The average score for succesfully attacked images at TN for N2:(transeferable samples divided by the TOTAL nnumber of adversarial samples) ",
          #    confidence_score_N2_tmp_all_samples/len(adv_score_mismatch_scores[:,0]))
     #   except:
      #      print(
        #        "The average score for succesfully attacked images at TN for N2:(transeferable samples divided by the TOTAL nnumber of adversarial samples - NO samples found) ", 0)


        # Force code to run on CPU so that it does not bother concurrent tasks that use GPU(s)
    #with tf.device('/cpu:0'):  # ('/cpu:0', '/gpu:0', '/gpu:2'): # ('/cpu:0'):
    print(datetime.datetime.now())
    main()
    print(datetime.datetime.now())