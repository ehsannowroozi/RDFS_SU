# all data: 323480
# train data: 226436
#validation data: 64696
# test data: 32348

import random
import shutil

def choose_indices(num_samples):
    train_num = int(num_samples*0.7)
    val_num = int(num_samples * 0.2)
    test_num = int(num_samples - val_num - train_num)

    train = []
    val = []
    test = []

    random.seed(100)
    temp = random.sample(range(num_samples), num_samples)
    train = temp[0:train_num]
    val = temp[train_num:train_num+val_num]
    test = temp[(train_num+val_num):(train_num+val_num+test_num)]

    print(len(test))
    print(len(val))
    print(len(train))

    return train,val,test

def copy_train(train_indices, class_name, count):
    len_data = len(train_indices)
    for i in range(len_data):
        if i%1000 == 0:
            print(i)
        if count < 86352 or count > 149332:
            original = 'F:/ehsan/'+class_name+'/img'+str(train_indices[i])+'.jpg'
            target = 'F:/ehsan/dataset/train/fake/'+ str(count) +'.jpg'
            count += 1
            shutil.copyfile(original, target)
        else:
            count+=1

    print("train finished")
    print("train count:", count)


def copy_val(val_indices, class_name, count):
    len_data = len(val_indices)
    for i in range(len_data):
        if i%1000 == 0:
            print(i)
        original = 'F:/ehsan/'+ class_name +'/img' + str(val_indices[i]) + '.jpg'
        target = 'F:/ehsan/dataset/validation/fake/' + str(count) + '.jpg'
        shutil.copyfile(original, target)
        count += 1

    print("validation finished")
    print("validation count:", count)

def copy_test(test_indices, class_name, count):
    len_data = len(test_indices)
    for i in range(len_data):
        if i%1000 == 0:
            print(i)
        original = 'F:/ehsan/'+ class_name +'/img' + str(test_indices[i]) + '.jpg'
        target = 'F:/ehsan/dataset/test/fake/' + str(count) + '.jpg'
        shutil.copyfile(original, target)
        count += 1

    print("test finished")
    print("test count:", count)

#countClasses = '{"Fuzzers": 24245, "Analysis": 2676, "Backdoors": 533, "DoS": 16352, "Exploits": 44524, "Generic": 215481, "Reconnaissance": 13986, "Shellcode": 1510, "Worms": 173, "normal": 323480}'
#count_train= 71619
count_train= 223633
count_val = 63893
count_test = 31945
class_name = 'Worms'
# number of samples of specific type of class, e.g. for Worms is 173
# this is for splitting in equal proportion each classes in train, test and validation sets
train,val,test = choose_indices(173)

copy_train(train, class_name, count_train)

copy_val(val, class_name, count_val)

copy_test(test, class_name, count_test)

