import cv2
import os
import numpy as np

# path
pathR = r'F:/ehsan/dataset/test/pristine/'
pathS = r'F:/ehsan/dataset64/test/pristine/'

for i in range(0,31945):
    if i%1000 == 0:
        print(i)
    try:
        img = cv2.imread(pathR + str(i) + ".jpg", cv2.IMREAD_GRAYSCALE)
        #print(img)
        dim = (64, 64)
        # resize image
        resized = cv2.resize(img, dim, interpolation=cv2.INTER_AREA)
        cv2.imwrite(pathS + str(i) + ".jpg", resized)
    except Exception as e:
        print(str(e))