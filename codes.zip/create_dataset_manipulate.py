import pandas as pd
from sklearn.preprocessing import OrdinalEncoder
from PIL import Image
import matplotlib.pyplot as plt
from ipaddress import IPv4Address

import numpy as np
import csv

import os
import json

path = "F:/ehsan/"
print(os.getcwd())
os.chdir(path)
print(os.getcwd())

headers = ["srcip", "sport", "dstip", "dsport", "proto", "state", "dur", "sbytes", "dbytes", "sttl", "dttl", \
    "sloss", "dloss", "service", "Sload", "Dload", "Spkts", "Dpkts", "swin", "dwin", "stcpb", "dtcpb", \
         "smeansz", "dmeansz", "trans_depth", "res_bdy_len", "Sjit", "Djit", "Stime", "Ltime", \
             "Sintpkt", "Dintpkt", "tcprtt", "synack", "ackdat", "is_sm_ips_ports", "ct_state_ttl", \
                  "ct_flw_http_mthd", "is_ftp_login", "ct_ftp_cmd", "ct_srv_src", "ct_srv_dst", "ct_dst_ltm", \
                      "ct_src_ltm", "ct_src_dport_ltm", "ct_dst_sport_ltm", "ct_dst_src_ltm", "attack_cat"]

#df = pd.DataFrame(table, columns =headers)
df = pd.read_csv(path + "result.csv", header=None, names=headers, na_values="?" )
temDF = df
temDF = temDF.fillna({"attack_cat": "normal"}) #fill nan values with 0.0

ord_enc = OrdinalEncoder()
temDF["proto"] = ord_enc.fit_transform(temDF[["proto"]])
temDF["state"] = ord_enc.fit_transform(temDF[["state"]])
temDF["service"] = ord_enc.fit_transform(temDF[["service"]])
temDF['attack_cat'] = temDF['attack_cat'].str.strip()

temDF.head(5)

countClasses = '{"Fuzzers": 24245, "Analysis": 2676, "Backdoors": 533, "DoS": 16352, "Exploits": 44524, "Generic": 215481, "Reconnaissance": 13986, "Shellcode": 1510, "Worms": 173, "normal": 0}'
classes = json.loads(countClasses)
df = temDF
print(len(df))
count = 0
for j in range(0, 47):
    pd.to_numeric(df.iloc[:, j], downcast='float')

nd = df.iloc[:, :47].to_numpy()
print(nd.shape)
# sort_nd = nd[nd[:, 46].argsort()]
sord_nd_features = nd[:, 5:]
print(sord_nd_features.shape)
sord_nd_features_normed = 255 * (sord_nd_features - sord_nd_features.min(0)) / sord_nd_features.ptp(0)
print(sord_nd_features_normed.shape)

print(os.getcwd())
os.chdir(path)
print(os.getcwd())

for item in classes:
    if not (os.path.isdir(path + item)):
        os.mkdir(item)

for i in range(0, len(df)):
    if i % 1000 == 0:
        print(i)
        print(classes)
    dirName = str(df.loc[i, "attack_cat"])
    if dirName == 'Worms':
        array = np.reshape(sord_nd_features[i], (7, 6))
        im = Image.fromarray(array)
        im = im.convert("L")
        im = im.resize((64, 64))

        if dirName in classes:
            count = classes[dirName]
            classes[dirName] += 1
            im.save(path + dirName + "/img%d.jpg" % count)

print(count)
print(classes)

