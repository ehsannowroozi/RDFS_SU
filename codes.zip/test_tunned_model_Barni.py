
import foolbox
from foolbox.models import KerasModel
import numpy as np
import matplotlib.pyplot as plt
from tensorflow import keras
from keras.models import load_model
from keras.datasets import mnist
from imageio import imread
from glob import glob
#from utils import force_linear_activation
import cv2
from PIL import Image
import math
import tensorflow as tf
import statistics
import datetime
from tensorflow.keras import regularizers
from tensorflow.keras.initializers import TruncatedNormal, Constant
from tensorflow.keras.layers import *
from tensorflow.keras.models import save_model
import csv
import os


gpus = tf.config.experimental.list_physical_devices('GPU')
print(tf.config.experimental.set_memory_growth(gpus[0], True))

result_dir = '/home/mhm/ehsan/Results_barni/'
os.chdir('/home/mhm/ehsan/Networks/Networks/Codes/Aware_Models/BarniNet')
#directories = [name for name in os.listdir(".") if os.path.isdir(name)]
model_names = [name for name in os.listdir('.') if os.path.isfile(name)]
model_names.sort()

#test_attack = "cw_conf_0"
#model_name = "Aware_Models/BarniNet_BIM_ep_10.h5"
#original_model = '../../../Network_Model/BarniNet.h5.h5'
#model = load_model(model_name)
model_set = model_names[24:]
for mdl_name in model_set:
    print(f"/////////// Load Model {mdl_name}")
    model = load_model('/home/mhm/ehsan/Networks/Networks/Codes/Aware_Models/BarniNet/'+ mdl_name)

    with open('/home/mhm/ehsan/Results_Tunned_Barni.csv', 'a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([''])

    os.chdir('/home/mhm/ehsan/Results_barni')
    directories = [name for name in os.listdir(".") if os.path.isdir(name)]
    directories.sort()

    for dir in directories:

        os.chdir('/home/mhm/ehsan/Results_barni/' + dir + "/npy/")
        files_names = [name for name in os.listdir('.') if os.path.isfile(name)]
        files_names.sort()

        test_images = []
        test_images_names = []

        for file in files_names:

            if not file == "tunning.csv":
                data = np.load(result_dir + dir + '/npy/' + file)
                array_sum = np.sum(data)
                array_has_nan = np.isnan(array_sum)
                if array_has_nan:
                    # os.remove(result_dir + dir + '/npy/'+ file)
                    # print(f"Delete index {file}");
                    continue
                else:
                    test_images.append(data)
                    test_images_names.append(file)

        if (len(test_images) == 0):
            print(f"Attack {dir} Terminated")
            with open('/home/mhm/ehsan/Results_Tunned_Barni.csv', 'a', newline='') as file:
                writer = csv.writer(file)
                writer.writerow([mdl_name , dir, "Not Sufficient Files"])
        else:
            test_img_np = np.array(test_images)
            X = test_img_np.reshape(test_img_np.shape[0], 64, 64, 1)
            X = X/255.
            Y = np.ones(len(X))
            y_test = tf.keras.utils.to_categorical(Y, 2)
            score2 = model.evaluate(X, y_test, verbose=2)
            predicted_legitimate_labels2 = np.argmax(model.predict(X), axis=1)
            #print(predicted_legitimate_labels2)
            #print(score2[1])
            with open('/home/mhm/ehsan/Results_Tunned_Barni.csv', 'a', newline='') as file:
                writer = csv.writer(file)
                writer.writerow([mdl_name , dir, len(X), score2[1]])
                print(f"Save Results {mdl_name} for {dir} \n")