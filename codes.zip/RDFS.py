from keras.models import load_model, Model
from glob import glob
from keras.preprocessing.image import img_to_array, load_img
import numpy as np
import os

def get_attack_files(result_dir, attack_name):
    os.chdir(result_dir + attack_name + '/npy')
    files_name = [name for name in os.listdir('.') if os.path.isfile(name)]
    files_name.sort()
    images = []
    image_names = []
    for file in files_name:
        if not file == "tunning.csv":
            data = np.load(result_dir + dir + '/npy/' + file)
            array_sum = np.sum(data)
            array_has_nan = np.isnan(array_sum)
            if array_has_nan:
                # os.remove(result_dir + dir + '/npy/'+ file)
                # print(f"Delete index {file}");
                continue
            else:
                images.append(data)
                image_names.append(file)
    return images


if __name__ == '__main__':

    idx1 = [400]
    sizeII = 50  # different cases (example 20 different cases)

    StammNet_model_path = r'/home/mhm/ehsan/Network_Model/Model_BayerNet_ImproveSec.h5'
    StammNet_model = load_model(StammNet_model_path)
    StammNet_model_fe = Model(inputs=StammNet_model.input, outputs=StammNet_model.get_layer(
        'flatten_1').output)  # takes bounds[0,1] shape(1,128,128,1) as input
    Model.summary(StammNet_model_fe)

    ''' image lists '''
    StammNet_imlist_pristine_Tr = glob(r'/home/mhm/ehsan/dataset64/train/pristine/*.jpg') #223000
    StammNet_imlist_pristine_Val = glob(r'/home/mhm/ehsan/dataset64/validation/pristine/*.jpg') #65000
    StammNet_imlist_pristine_Te = glob(r'/home/mhm/ehsan/dataset64/test/pristine/*.jpg') #31000

    StammNet_imlist_resize08_Tr = glob(r'/home/mhm/ehsan/dataset64/train/fake/*.jpg')
    StammNet_imlist_resize08_Val = glob(r'/home/mhm/ehsan/dataset64/validation/fake/*.jpg')
    StammNet_imlist_resize08_Te = glob(r'/home/mhm/ehsan/dataset64/test/fake/*.jpg')

    StammNet_imlist_JSMA01 = glob(r'/home/mhm/ehsan/Results/JSMA_theta_0.1/npy/*.npy') #500

    StammNet_imlist_IFGSM10 = glob(r'/home/mhm/ehsan/Results/IFGSM_epsilon_10/npy/*.npy') #500

    StammNet_imlist_FGSM10 = glob(r'/home/mhm/ehsan/Results/FGSM_epsilon_10/npy/*.npy')  # 500

    StammNet_imlist_BIM100 = glob(r'/home/mhm/ehsan/Results/BIM_ep_100/npy/*.npy')  # 500

    StammNet_imlist_LBGFS = glob(r'/home/mhm/ehsan/Results/LBGFS/npy/*.npy')  # 500

    StammNet_imlist_Deepfool = glob(r'/home/mhm/ehsan/Results/Deepfool/npy/*.npy')  # 500

    StammNet_imlist_PGD005 = glob(r'/home/mhm/ehsan/Results/PGD_ep_005/npy/*.npy')  # 500

    StammNet_imlist_CW0 = glob(r'/home/mhm/ehsan/Results/cw_conf_0/npy/*.npy')  # 500

    StammNet_imlist_CW100 = glob(r'/home/mhm/ehsan/Results/cw_conf_100/npy/*.npy')  # 500

    ###########################################################
    # Pristine TR + Val + Test
    ###########################################################

    feStamm_pristine_Tr = np.zeros(1728)
    for idx, im_file in enumerate(StammNet_imlist_pristine_Tr[:60000]):
        print('dealing with number {} image in StammNet_imlist_pristine_Tr'.format(idx))
        image = img_to_array(load_img(im_file, target_size=(64, 64), color_mode='grayscale')) / 255
        feStamm_pristine_Tr = np.vstack((feStamm_pristine_Tr, StammNet_model_fe.predict(image.reshape(1, 64, 64, 1))))
    feStamm_pristine_Tr = np.delete(feStamm_pristine_Tr, 0, 0)
    np.save('/home/mhm/ehsan/RDFS/5/test/inter_features/StammNet_model_fe_pristine_Tr.npy', feStamm_pristine_Tr)

    feStamm_pristine_Val = np.zeros(1728)
    for idx, im_file in enumerate(StammNet_imlist_pristine_Val[:5000]):
        print('dealing with number {} image in StammNet_imlist_pristine_Val'.format(idx))
        image = img_to_array(load_img(im_file, target_size=(64, 64), color_mode='grayscale')) / 255
        feStamm_pristine_Val = np.vstack((feStamm_pristine_Val, StammNet_model_fe.predict(image.reshape(1, 64, 64, 1))))
    feStamm_pristine_Val = np.delete(feStamm_pristine_Val, 0, 0)
    np.save('/home/mhm/ehsan/RDFS/5/test/inter_features/StammNet_model_fe_pristine_Val.npy', feStamm_pristine_Val)

    feStamm_pristine_Te = np.zeros(1728)
    for idx, im_file in enumerate(StammNet_imlist_pristine_Te[:10000]):
        print('dealing with number {} image in StammNet_imlist_pristine_Te'.format(idx))
        image = img_to_array(load_img(im_file, target_size=(64, 64), color_mode='grayscale')) / 255
        feStamm_pristine_Te = np.vstack((feStamm_pristine_Te, StammNet_model_fe.predict(image.reshape(1, 64, 64, 1))))
    feStamm_pristine_Te = np.delete(feStamm_pristine_Te, 0, 0)
    np.save('/home/mhm/ehsan/RDFS/5/test/inter_features/StammNet_model_fe_pristine_Te.npy', feStamm_pristine_Te)

    concatenate_Pristine = np.concatenate(
        (feStamm_pristine_Tr[0:60000, :], feStamm_pristine_Val[0:5000, :], feStamm_pristine_Te[0:10000, :]), axis=0)
    np.save('/home/mhm/ehsan/RDFS/5/test/inter_features/StammNet_model_fe_pristine_Concat.npy', concatenate_Pristine)

    #########################################################################
    #      Resize08 flatten features  (Tr+Val+Te)
    #########################################################################
    feStamm_resize08_Tr = np.zeros(1728)
    for idx, im_file in enumerate(StammNet_imlist_resize08_Tr[:60000]):
        print('dealing with number {} image in StammNet_imlist_resize08_Tr'.format(idx))
        image = img_to_array(load_img(im_file, target_size=(64, 64), color_mode='grayscale')) / 255
        feStamm_resize08_Tr = np.vstack((feStamm_resize08_Tr, StammNet_model_fe.predict(image.reshape(1, 64, 64, 1))))
    feStamm_resize08_Tr = np.delete(feStamm_resize08_Tr, 0, 0)
    np.save('/home/mhm/ehsan/RDFS/5/test/inter_features/StammNet_model_fe_resize08_Tr.npy', feStamm_resize08_Tr)

    feStamm_resize08_Val = np.zeros(1728)
    for idx, im_file in enumerate(StammNet_imlist_resize08_Val[:5000]):
        print('dealing with number {} image in StammNet_imlist_resize08_Val'.format(idx))
        image = img_to_array(load_img(im_file, target_size=(64, 64), color_mode='grayscale')) / 255
        feStamm_resize08_Val = np.vstack((feStamm_resize08_Val, StammNet_model_fe.predict(image.reshape(1, 64, 64, 1))))
    feStamm_resize08_Val = np.delete(feStamm_resize08_Val, 0, 0)
    np.save('/home/mhm/ehsan/RDFS/5/test/inter_features/StammNet_model_fe_resize08_Val.npy', feStamm_resize08_Val)

    feStamm_resize08_Te = np.zeros(1728)
    for idx, im_file in enumerate(StammNet_imlist_resize08_Te[:10000]):
        print('dealing with number {} image in StammNet_imlist_resize08_Te'.format(idx))
        image = img_to_array(load_img(im_file, target_size=(64, 64), color_mode='grayscale')) / 255
        feStamm_resize08_Te = np.vstack((feStamm_resize08_Te, StammNet_model_fe.predict(image.reshape(1, 64, 64, 1))))
    feStamm_resize08_Te = np.delete(feStamm_resize08_Te, 0, 0)
    np.save('/home/mhm/ehsan/RDFS/5/test/inter_features/StammNet_model_fe_resize08_Te.npy', feStamm_resize08_Te)

    concatenate_resize08 = np.concatenate(
        (feStamm_resize08_Tr[0:60000, :], feStamm_resize08_Val[0:5000, :], feStamm_resize08_Te[0:10000, :]), axis=0)
    np.save('/home/mhm/ehsan/RDFS/5/test/inter_features/StammNet_model_fe_resize08_Concat.npy', concatenate_resize08)

    ########################################################################
    #      Adversarial JSMA 0.01
    ########################################################################
    feStamm_JSMA001 = np.zeros(1728)
    for idx, im_file in enumerate(StammNet_imlist_JSMA01):
        print('dealing with number {} image in StammNet_imlist_JSMA001'.format(idx))
        image = np.load(im_file)
        image = image / 255
        feStamm_JSMA001 = np.vstack((feStamm_JSMA001, StammNet_model_fe.predict(image.reshape(1, 64, 64, 1))))
    feStamm_JSMA001 = np.delete(feStamm_JSMA001, 0, 0)
    np.save('/home/mhm/ehsan/RDFS/5/test/inter_features/StammNet_model_fe_JSMA001.npy', feStamm_JSMA001)

    ########################################################################
    #      IFGSM eps 10
    ########################################################################
    feStamm_IFGSM10 = np.zeros(1728)
    for idx, im_file in enumerate(StammNet_imlist_IFGSM10):
        print('dealing with number {} image in StammNet_imlist_IFGSM10'.format(idx))
        image = np.load(im_file)
        image = image / 255
        feStamm_IFGSM10 = np.vstack((feStamm_IFGSM10, StammNet_model_fe.predict(image.reshape(1, 64, 64, 1))))
    feStamm_IFGSM10 = np.delete(feStamm_IFGSM10, 0, 0)
    np.save('/home/mhm/ehsan/RDFS/5/test/inter_features/StammNet_model_fe_IFGSM10.npy', feStamm_IFGSM10)

    ########################################################################
    #      FGSM eps 10
    ########################################################################
    feStamm_FGSM10 = np.zeros(1728)
    for idx, im_file in enumerate(StammNet_imlist_FGSM10):
        print('dealing with number {} image in StammNet_imlist_FGSM10'.format(idx))
        image = np.load(im_file)
        image = image / 255
        feStamm_FGSM10 = np.vstack((feStamm_FGSM10, StammNet_model_fe.predict(image.reshape(1, 64, 64, 1))))
    feStamm_FGSM10 = np.delete(feStamm_IFGSM10, 0, 0)
    np.save('/home/mhm/ehsan/RDFS/5/test/inter_features/StammNet_model_fe_FGSM10.npy', feStamm_FGSM10)

    ########################################################################
    #      BIM eps 100
    ########################################################################
    feStamm_BIM100 = np.zeros(1728)
    for idx, im_file in enumerate(StammNet_imlist_BIM100):
        print('dealing with number {} image in StammNet_imlist_BIM100'.format(idx))
        image = np.load(im_file)
        image = image / 255
        feStamm_BIM100 = np.vstack((feStamm_BIM100, StammNet_model_fe.predict(image.reshape(1, 64, 64, 1))))
    feStamm_BIM100 = np.delete(feStamm_BIM100, 0, 0)
    np.save('/home/mhm/ehsan/RDFS/5/test/inter_features/StammNet_model_fe_BIM100.npy', feStamm_BIM100)

    ########################################################################
    #      LBGFS
    ########################################################################
    feStamm_LBGFS = np.zeros(1728)
    for idx, im_file in enumerate(StammNet_imlist_LBGFS):
        print('dealing with number {} image in StammNet_imlist_LBGFS'.format(idx))
        image = np.load(im_file)
        image = image / 255
        feStamm_LBGFS = np.vstack((feStamm_LBGFS, StammNet_model_fe.predict(image.reshape(1, 64, 64, 1))))
    feStamm_LBGFS = np.delete(feStamm_LBGFS, 0, 0)
    np.save('/home/mhm/ehsan/RDFS/5/test/inter_features/StammNet_model_fe_LBGFS.npy', feStamm_LBGFS)

    ########################################################################
    #      Deepfool
    ########################################################################
    feStamm_Deepfool = np.zeros(1728)
    for idx, im_file in enumerate(StammNet_imlist_Deepfool):
        print('dealing with number {} image in StammNet_imlist_Deepfool'.format(idx))
        image = np.load(im_file)
        image = image / 255
        feStamm_Deepfool = np.vstack((feStamm_Deepfool, StammNet_model_fe.predict(image.reshape(1, 64, 64, 1))))
    feStamm_Deepfool = np.delete(feStamm_Deepfool, 0, 0)
    np.save('/home/mhm/ehsan/RDFS/5/test/inter_features/StammNet_model_fe_Deepfool.npy', feStamm_Deepfool)

    ########################################################################
    #      PDG 005
    ########################################################################
    feStamm_PGD005 = np.zeros(1728)
    for idx, im_file in enumerate(StammNet_imlist_PGD005):
        print('dealing with number {} image in StammNet_imlist_PGD005'.format(idx))
        image = np.load(im_file)
        image = image / 255
        feStamm_PGD005 = np.vstack((feStamm_PGD005, StammNet_model_fe.predict(image.reshape(1, 64, 64, 1))))
    feStamm_PDG005 = np.delete(feStamm_PGD005, 0, 0)
    np.save('/home/mhm/ehsan/RDFS/5/test/inter_features/StammNet_model_fe_PGD005.npy', feStamm_PGD005)

    ########################################################################
    #      CW conf 0
    ########################################################################
    feStamm_CW0 = np.zeros(1728)
    for idx, im_file in enumerate(StammNet_imlist_CW0):
        print('dealing with number {} image in StammNet_imlist_CW0'.format(idx))
        image = np.load(im_file)
        image = image / 255
        feStamm_CW0 = np.vstack((feStamm_CW0, StammNet_model_fe.predict(image.reshape(1, 64, 64, 1))))
    feStamm_CW0 = np.delete(feStamm_CW0, 0, 0)
    np.save('/home/mhm/ehsan/RDFS/5/test/inter_features/StammNet_model_fe_CW0.npy', feStamm_CW0)

    ########################################################################
    #      CW conf 100
    ########################################################################
    feStamm_CW100 = np.zeros(1728)
    for idx, im_file in enumerate(StammNet_imlist_CW100):
        print('dealing with number {} image in StammNet_imlist_CW100'.format(idx))
        image = np.load(im_file)
        image = image / 255
        feStamm_CW100 = np.vstack((feStamm_CW100, StammNet_model_fe.predict(image.reshape(1, 64, 64, 1))))
    feStamm_CW100 = np.delete(feStamm_CW100, 0, 0)
    np.save('/home/mhm/ehsan/RDFS/5/test/inter_features/StammNet_model_fe_CW100.npy', feStamm_CW100)

    ########################################################################
    #     Load all features
    ########################################################################

    pristine = np.load('/home/mhm/ehsan/RDFS/5/test/inter_features/StammNet_model_fe_pristine_Concat.npy')
    resize08 = np.load('/home/mhm/ehsan/RDFS/5/test/inter_features/StammNet_model_fe_resize08_Concat.npy')
    JSMA01 = np.load('/home/mhm/ehsan/RDFS/5/test/inter_features/StammNet_model_fe_JSMA001.npy')
    IFGSM10 = np.load('/home/mhm/ehsan/RDFS/5/test/inter_features/StammNet_model_fe_IFGSM10.npy')
    BIM100 = np.load('/home/mhm/ehsan/RDFS/5/test/inter_features/StammNet_model_fe_BIM100.npy')
    LBGFS = np.load('/home/mhm/ehsan/RDFS/5/test/inter_features/StammNet_model_fe_LBGFS.npy')
    Deepfool = np.load('/home/mhm/ehsan/RDFS/5/test/inter_features/StammNet_model_fe_Deepfool.npy')
    PGD005 = np.load('/home/mhm/ehsan/RDFS/5/test/inter_features/StammNet_model_fe_PGD005.npy')
    CW0 = np.load('/home/mhm/ehsan/RDFS/5/test/inter_features/StammNet_model_fe_CW0.npy')
    CW100 = np.load('/home/mhm/ehsan/RDFS/5/test/inter_features/StammNet_model_fe_CW100.npy')
    FGSM10 = np.load('/home/mhm/ehsan/RDFS/5/test/inter_features/StammNet_model_fe_FGSM10.npy')

    print('pristine shape', pristine.shape)
    print('resize08 shape', resize08.shape)
    print('JSMA01 shape', JSMA01.shape)
    print('IFGSM10 shape', IFGSM10.shape)

    assert len(pristine[0]) == pristine.shape[1]
    index = np.array(range(pristine.shape[1]))

    for I in idx1:
        for idx in np.arange(sizeII):
            Stamm_random_pattern = np.random.choice(index, size=I, replace=False)
            Stamm_random_pattern.sort()
            np.save('/home/mhm/ehsan/RDFS/5/test/inter_features_{}/StammNet_random_pattern_{}.npy'.format(I, idx), Stamm_random_pattern)

            '''Using pattern generate subset'''
            pattern_path = ('/home/mhm/ehsan/RDFS/5/test/inter_features_{}/StammNet_random_pattern_{}.npy'.format(I, idx))
            Stamm_random_pattern = np.load(pattern_path)

            Stamm_pristine = np.array([pristine[:, j] for j in Stamm_random_pattern]).T
            Stamm_resize08 = np.array([resize08[:, j] for j in Stamm_random_pattern]).T

            Stamm_JSMA01 = np.array([JSMA01[:, j] for j in Stamm_random_pattern]).T

            Stamm_IFGSM10 = np.array([IFGSM10[:, j] for j in Stamm_random_pattern]).T

            Stamm_FGSM10 = np.array([FGSM10[:, j] for j in Stamm_random_pattern]).T

            Stamm_BIM100 = np.array([BIM100[:, j] for j in Stamm_random_pattern]).T

            Stamm_LBGFS = np.array([LBGFS[:, j] for j in Stamm_random_pattern]).T

            Stamm_Deepfool = np.array([Deepfool[:, j] for j in Stamm_random_pattern]).T

            Stamm_PGD005 = np.array([PGD005[:, j] for j in Stamm_random_pattern]).T

            Stamm_CW0 = np.array([CW0[:, j] for j in Stamm_random_pattern]).T

            Stamm_CW100 = np.array([CW100[:, j] for j in Stamm_random_pattern]).T

            np.save('/home/mhm/ehsan/RDFS/5/test/inter_features_{}/StammNet_subset_pristine_{}.npy'.format(I, idx), Stamm_pristine)
            np.save('/home/mhm/ehsan/RDFS/5/test/inter_features_{}/StammNet_subset_resize08_{}.npy'.format(I, idx), Stamm_resize08)

            np.save('/home/mhm/ehsan/RDFS/5/test/inter_features_{}/StammNet_subset_JSMA001_{}.npy'.format(I, idx), Stamm_JSMA01)

            np.save('/home/mhm/ehsan/RDFS/5/test/inter_features_{}/StammNet_subset_IFGSM10_{}.npy'.format(I, idx), Stamm_IFGSM10)

            np.save('/home/mhm/ehsan/RDFS/5/test/inter_features_{}/StammNet_subset_FGSM10_{}.npy'.format(I, idx),StammNet_imlist_FGSM10)

            np.save('/home/mhm/ehsan/RDFS/5/test/inter_features_{}/StammNet_subset_BIM100_{}.npy'.format(I, idx),
                    Stamm_BIM100)

            np.save('/home/mhm/ehsan/RDFS/5/test/inter_features_{}/StammNet_subset_LBGFS_{}.npy'.format(I, idx),
                    Stamm_LBGFS)

            np.save('/home/mhm/ehsan/RDFS/5/test/inter_features_{}/StammNet_subset_Deepfool_{}.npy'.format(I, idx),
                    Stamm_Deepfool)

            np.save('/home/mhm/ehsan/RDFS/5/test/inter_features_{}/StammNet_subset_PGD005_{}.npy'.format(I, idx),
                    Stamm_PGD005)

            np.save('/home/mhm/ehsan/RDFS/5/test/inter_features_{}/StammNet_subset_CW0_{}.npy'.format(I, idx),
                    Stamm_CW0)

            np.save('/home/mhm/ehsan/RDFS/5/test/inter_features_{}/StammNet_subset_CW100_{}.npy'.format(I, idx),
                    Stamm_CW100)