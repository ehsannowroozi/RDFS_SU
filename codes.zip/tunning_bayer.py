
import foolbox
from foolbox.models import KerasModel
import numpy as np
import matplotlib.pyplot as plt
from tensorflow import keras
from keras.models import load_model
from keras.datasets import mnist
from imageio import imread
from glob import glob
#from utils import force_linear_activation
import cv2
from PIL import Image
import math
import tensorflow as tf
import statistics
import datetime
from tensorflow.keras import regularizers
from tensorflow.keras.initializers import TruncatedNormal, Constant
from tensorflow.keras.layers import *
from tensorflow.keras.models import save_model
from sklearn.model_selection import train_test_split
import os
import csv

gpus = tf.config.experimental.list_physical_devices('GPU')
print(tf.config.experimental.set_memory_growth(gpus[0], True))

with open('/home/mhm/ehsan/tunning_bayer.csv', 'w', newline='') as file:
    print("tunning_bayer.csv created")

result_dir = '/home/mhm/ehsan/Results/'
os.chdir('/home/mhm/ehsan/Results')
directories = [name for name in os.listdir(".") if os.path.isdir(name)]
#directories = ["FGSM_epsilon_10", "BIM_ep_10", "cw_conf_100"]
for dir in directories:
    print(f"/////////// Start Tunning on {dir}")
    attack_name = dir
    model_name = "BarniNet"
    os.chdir(result_dir + dir + '/npy')
    files_name = [name for name in os.listdir('.') if os.path.isfile(name)]
    files_name.sort()
    num_files = len(files_name)
    images = []
    image_names = []
    for file in files_name:
        if not file == "tunning.csv":
            data = np.load(result_dir + dir +'/npy/' + file)
            array_sum = np.sum(data)
            array_has_nan = np.isnan(array_sum)
            if array_has_nan:
                continue
            else:
                images.append(data)
                image_names.append(file)

    if (len(images) == 0):
        print(f"Attack {dir} Terminated")
    else:
        image_np = np.array(images)
        #image_np = np.nan_to_num(image_np, nan=0.0)
        X = image_np.reshape(image_np.shape[0], 64, 64, 1)
        X = X/255.
        Y = np.ones(image_np.shape[0])
        #print(image_np.shape)

        model = load_model('/home/mhm/ehsan/Network_Model/Model_BayerNet_ImproveSec.h5')
        print("**************** Raw Model Summary *********************")
        print(model.summary())
        Y = tf.keras.utils.to_categorical(Y, 2)
        score1 = model.evaluate(X, Y, verbose=2)
        predicted_legitimate_labels1 = np.argmax(model.predict(X), axis=1)
        X_final = []
        Y_final = []
        ones_count = np.count_nonzero(predicted_legitimate_labels1 == 1)
        ones_zeros = np.count_nonzero(predicted_legitimate_labels1 == 0)
        for i in range(len(predicted_legitimate_labels1)):
            if predicted_legitimate_labels1[i] == 0:
                X_final.append(X[i])

        X_final = np.array(X_final)
        X_final = X_final.reshape(X_final.shape[0], 64, 64, 1)
        Y_final = np.tile(1, X_final.shape[0])
        Y_final = tf.keras.utils.to_categorical(Y_final, 2)

        print("**************** Accuracy raw Model *********************")
        print('Accuracy on legitimate images (all): {:3.4f}'.format(score1[1]))

        inputs = model.layers[0].output_shape[1:4]
        inputs2 = keras.Input(shape = (64,64,1))

        print("****** Freezing Layers ********")
        for layer in model.layers[:9]:
            layer.trainable = False


        # Create new model on top
        inputs = keras.Input(shape=(64, 64, 1))
        new_model = keras.Model(model.inputs, model.outputs)

        print("**************** New Model Summary *********************")
        #new_model.summary()

        new_model.compile(loss=tf.keras.losses.categorical_crossentropy,
                      optimizer=tf.keras.optimizers.Adam(lr=1e-06), metrics=['accuracy'])
        history = new_model.fit(X_final, Y_final, batch_size=8, epochs=20, verbose=2, validation_split=0.2)
        # summarize history for accuracy
        plt.plot(history.history['accuracy'])
        plt.plot(history.history['val_accuracy'])
        plt.title('model accuracy')
        plt.ylabel('accuracy')
        plt.xlabel('epoch')
        plt.legend(['train', 'test'], loc='upper left')
        plt.show()
        # summarize history for loss
        plt.plot(history.history['loss'])
        plt.plot(history.history['val_loss'])
        plt.title('model loss')
        plt.ylabel('loss')
        plt.xlabel('epoch')
        plt.legend(['train', 'test'], loc='upper left')
        plt.show()

        for layer in model.layers[:9]:
            layer.trainable = True

        new_model.compile(loss=tf.keras.losses.categorical_crossentropy,
                      optimizer=tf.keras.optimizers.Adam(lr=1e-06), metrics=['accuracy'])
        X_train, X_test, y_train, y_test = train_test_split(X_final, Y_final, test_size=0.2, random_state=236)
        history = new_model.fit(X_train, y_train, batch_size=8, epochs=20, verbose=2, validation_split=0.2)
        score2 = new_model.evaluate(X_test, y_test, verbose=2)
        predicted_legitimate_labels2 = np.argmax(new_model.predict(X), axis=1)
        print(predicted_legitimate_labels2)

        print("**************** Save new model and saving the results *********************")
        save_model(new_model, '/home/mhm/ehsan/Networks/Networks/Codes/Aware_Models/BayerNet_lr06_'+attack_name)
        new_model.save('/home/mhm/ehsan/Networks/Networks/Codes/Aware_Models/BayerNet_lr06_'+attack_name+".h5")
        print(f"/////////// Model Saved: {dir}")
        with open('/home/mhm/ehsan/tunning_bayer.csv', 'a', newline='') as file:
            writer = csv.writer(file)
            writer.writerow([model_name, dir, len(predicted_legitimate_labels2), score2[1]])