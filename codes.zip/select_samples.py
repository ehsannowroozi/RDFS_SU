# seed the pseudorandom number generator
from random import seed
from random import randint
from shutil import copyfile
# seed random number generator
seed(789456)
samples = 31945 # all samples
indices = [] # for saving indices of selected samples
required_samples = 500 # number of required samples
#select 500 unique indices
for i in range(required_samples):
    total = randint(0,31945)
    if total not in indices:
        indices.append(total)
    else:
        while total in indices:
            total = randint(0,31945)
        indices.append(total)
print(indices)

g = set(indices)

print(len(g))

path = '/home/m_mhm/ehsan/dataset64/test/fake/' # all samples path
save_path = '/home/m_mhm/ehsan/Network_Model/images/' # path of copying the selected samples

for i in range(required_samples):
    copyfile(path + str(indices[i]) + ".jpg", save_path + str(i) + ".jpg")
