for jj=0:0
    
%acc0=load('results_0.mat','accuracy');
%acc0=acc0.accuracy(1);

acc=sprintf('1728/results_%d.mat',jj);
acc=load(acc,'accuracy');
accc(jj+1)=acc.accuracy(1);

end

SUM=sum(accc);
avg=SUM/length(accc);

fprintf('Average Accuracy No Attack: %.3f \n',avg);